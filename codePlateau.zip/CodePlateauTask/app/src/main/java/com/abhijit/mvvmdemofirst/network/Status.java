package com.abhijit.mvvmdemofirst.network;

public enum Status {
    LOADING,
    SUCCESS,
    ERROR,
    COMPLETED
}
